package com.cg.hms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Room;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

@Transactional
@Repository
public class BookingDaoImpl implements IBookingDao {
	
	private Logger log = Logger.getLogger("BookingDAO");
	
	@PersistenceContext
	private EntityManager eManager;
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	saveBooking
		- Input Parameters	:	Booking object
		- Return Type		:	Boolean bcode
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	save booking details in the database
	********************************************************************************************************/	

	@Override
	public boolean saveBooking(Booking book) {
		boolean bcode = false;
		
		eManager.persist(book);
			
			return false;
		
	}
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	saveBooking
		- Input Parameters	:	Booking object
		- Return Type		:	Boolean bcode
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	save booking details in the database
	********************************************************************************************************/	



	@Override
	public List<Booking> listBookingDetailsByRoomid(int roomid)
			throws HMSException {
		List<Booking> bookList;
		try (Connection conn = DbUtil.getConnection();
				PreparedStatement st = conn
						.prepareStatement(IQueryMapper.LIST_BOOKING_DETAILS_BY_ROOMID);) {
			st.setInt(1, roomid);
			
			log.info("Retrieving Booking Details of particular Room using RoomId from the Database");
			
			ResultSet rs = st.executeQuery();
			bookList = new ArrayList<Booking>();
			Booking book = new Booking();
			while (rs.next()) {
				book.setBookingId(rs.getInt(1));
				book.setRoomId(rs.getInt(2));
				book.setUserId(rs.getInt(3));
				book.setfDate(rs.getDate(4));
				book.setfDate(rs.getDate(5));
				book.setAdults(rs.getInt(6));
				book.setChild(rs.getInt(7));
				book.setAmount(rs.getInt(8));
				bookList.add(book);
			}

		} catch (SQLException e) {
			log.error("SQL ERROR IN FETCHING ROOM BOOKING DATA FROM THE DATABASE");
			throw new HMSException("Unable To Fetch booking details");
		}
		return bookList;
	}
	
	//------------------------ 1. HotelManagementSystem --------------------------
	/*******************************************************************************************************
		- Function Name		:	findAmount
		- Input Parameters	:	Integer rcode
		- Return Type		:	Room object
		- Throws			:  	HMSException
		- Creation Date		:	10/10/2018
		- Description		:	fetch room rate details from the database
	********************************************************************************************************/
	
	@Override
	public Room findAmount(int rcode) throws HMSException {
		
			Room room = null;
			try (Connection conn = DbUtil.getConnection();
					PreparedStatement st = conn.prepareStatement(IQueryMapper.FIND_AMOUNT);)  {
				
				log.info("Fetch Room Rate Details from the Database");
				st.setInt(1, rcode);
				ResultSet rs = st.executeQuery();			
				if(rs.next()){
					room = new Room();
					room.setPerNightPrice(rs.getDouble(5));	
				}
				
			} catch (SQLException e) {
				log.error("SQL ERROR IN FETCHING ROOM RATE DATA FROM THE DATABASE");
				throw new HMSException("Unable To Fetch Amount");
			}
			return room;
		
	}
}
