package com.cg.hms.dao;

public interface IQueryMapper {
	
	public final String URL="jdbc:oracle:thin:@localhost:1521:xe";
	public final String USERNAME="system";
	public final String PASSWORD="orcl11g";

	public final String INSERT_USER = "INSERT INTO users VALUES(SEQ_UID.NEXTVAL,?,?,?,?,?,?,?)";
	public final String USER_ID_SEQUENCE = "SELECT SEQ_UID.CURRVAL FROM DUAL";

	public static final String GET_USER = "SELECT * FROM users WHERE userName=?";
	public static final String ADD_HOTEL = "INSERT INTO hotel VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	public static final String LIST_HOTELS = "SELECT * FROM hotel";
	public static final String DELETE_HOTEL = "DELETE FROM hotel where hotelId=? ";
	public static final String MODIFY_HOTEL = "UPDATE hotel SET description=? WHERE hotelId=?";
	public static final String FIND_HOTEL = "SELECT * FROM hotel WHERE hotelId=?";
	public static final String ADD_BOOKING = "INSERT INTO bookingdetails VALUES(?,?,?,?,?,?,?,?)";
	public static final String FIND_ROOMS = "SELECT * FROM roomdetails WHERE hotelId=? ";
	public static final String LIST_ROOMS = "SELECT * FROM roomdetails WHERE hotelId=? and roomType=? and availability='Yes'";
	public static final String FIND_AMOUNT = "SELECT * FROM roomdetails WHERE roomid=?";

	public static final String FIND_USER = "SELECT username FROM users WHERE userid IN(SELECT userid FROM bookingdetails WHERE roomId IN(SELECT roomId FROM roomdetails WHERE hotelId=?)) ";
	public static final String LIST_BOOKING_DETAILS = "SELECT * FROM bookingdetails WHERE roomId IN(SELECT roomId FROM roomdetails WHERE hotelId=?)";

	public static final String ADD_ROOM = "INSERT INTO roomdetails VALUES(?,?,?,?,?,?)";
	public static final String DELETE_ROOM = "DELETE FROM roomdetails where roomId=? ";
	public static final String FIND_ROOM_BY_ID = "SELECT * FROM roomdetails WHERE roomId=?";
	public static final String MODIFY_ROOM_AVAIL = "UPDATE roomdetails SET availability=? WHERE roomId=?";
	public static final String MODIFY_ROOM_RATE = "UPDATE roomdetails SET pernightrate=? WHERE roomId=?";

	public static final String LIST_BOOKING_DETAILS_BY_ROOMID = "SELECT * FROM bookingdetails WHERE roomid= ?";
	public static final String LIST_BOOKING_DETAILS_BY_HOTELID = "SELECT * FROM bookingdetails WHERE hotelid= ?";

	public static final String LIST_RESERVED_BOOKS = "SELECT logid,lmsBooks.bcode,studid,title,resvdt FROM lmsRegister INNER JOIN lmsBooks ON lmsRegister.bcode=lmsBooks.bcode WHERE isudt IS NULL";
}
