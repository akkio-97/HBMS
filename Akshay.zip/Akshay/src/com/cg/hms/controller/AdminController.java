package com.cg.hms.controller;
 
import java.util.List;
 








import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
 








import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
 








import com.cg.hms.bean.Booking;
import com.cg.hms.bean.Hotel;
import com.cg.hms.bean.Room;
import com.cg.hms.bean.User;
import com.cg.hms.dao.IHotelDAO;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.IAdminService;
import com.cg.hms.service.IHotelService;
import com.cg.hms.service.IRoomService;
import com.cg.hms.service.IUserService;
 
@Controller
public class AdminController {
	@Autowired
	public IHotelService hotelService;
 
	@Autowired
	public IAdminService adminService;
	
	@Autowired
	public IUserService userService;
 
	@Autowired
	public IRoomService roomService;
 
	@RequestMapping("/bookingadmin")
	public String bookingform(Model model) {
 
		model.addAttribute("obj", new User());
 
		return "BookingForm";
	}
	
	@RequestMapping("/adminHotel")
	public String adminHotel(Model model) {

		model.addAttribute("obj", new Hotel());

		return "adminHotel";
	}


	@RequestMapping("/adminAddHotel")
	public String adminAddHotel(Model model) {

		model.addAttribute("obj", new Hotel());

		return "adminAddHotel";
	}

	@RequestMapping("/adminDeleteHotel")
	public String adminDeleteHotel(Model model) throws HMSException {
		List<Hotel> hotelList;
		hotelList = hotelService.listHotels();
		model.addAttribute("hotelList", hotelList);

		System.out.println("hotelList " + hotelList);

		return "adminDeleteHotel";
	}

	@RequestMapping("/addHotelSubmit")
	public String addHotelSubmit(@ModelAttribute Hotel hotel, Model model,
			HttpServletRequest request) throws HMSException {

		System.out.println(adminService.addHotel(hotel));
		System.out.println("Reached addHotelSubmit");
		System.out.println(hotel);

		List<Hotel> hotelList;

		hotelList = hotelService.listHotels();
		model.addAttribute("hotelList", hotelList);
		return "adminDeleteHotel";
	}

	@RequestMapping("/deleteHotelSubmit")
	public String deleteHotelSubmit(@RequestParam("hotelId") int hotelId,
			Model model) throws HMSException {
		System.out.println(adminService.deleteHotel(hotelId));
		System.out.println("Reached deleteHotelSubmit");
		List<Hotel> hotelList;

		hotelList = hotelService.listHotels();
		model.addAttribute("hotelList", hotelList);
		return "adminDeleteHotel";
	}

	@RequestMapping("/adminModifyHotel")
	public String adminModifyHotel(Model model) throws HMSException {
		List<Hotel> hotelList;

		hotelList = hotelService.listHotels();
		model.addAttribute("hotelList", hotelList);

		return "adminModifyHotel";
	}

//	@RequestMapping("/modifyHotelDescription")
//	public String modifyHotelDescription(@RequestParam("hotelId") int hotelId,
//			Model model, HttpServletRequest request) throws HMSException {
//		String desc;
//		List<Hotel> hotelList;
//		hotelList = hotelService.listHotels();
//		Hotel hotel = adminService.modifyHotel(hotelId);
//		System.out.println(hotel);
//		HttpSession session = request.getSession();
//		session.setAttribute("hotel", hotel);
//		model.addAttribute("obj", hotel);
//
//		return "modifyHotelDescription";
//	}

//	@RequestMapping("/modifyHotelDescriptionSubmit")
//	public String modifyHotelDescriptionSubmit(
//			@RequestParam("hotelId") int hotelId, Model model)
//			throws HMSException {
//		String desc = "changed desc";
//		System.out.println(adminService.modifyHotel(hotelId));
//		System.out.println("Reached deleteHotelSubmit");
//		List<Hotel> hotelList;
//
//		hotelList = hotelService.listHotels();
//		model.addAttribute("hotelList", hotelList);
//		return "adminDeleteHotel";
//	}

	@RequestMapping("/addModifiedHotel")
	public String addModifiedHotel( Model model,
			HttpServletRequest request) throws HMSException {
		String desc = "changed desc";
		// System.out.println(adminService.modifyHotel(hotelId, desc));
		// System.out.println("Reached deleteHotelSubmit");
		// List<Hotel> hotelList;
		//
		// hotelList = hotelService.listHotels();
		// model.addAttribute("hotelList", hotelList);
		HttpSession session = request.getSession();
		Hotel hotel = (Hotel) session.getAttribute("hotel");
		System.out.println("nijdskljf");
		System.out.println(hotel);
		System.out.println("lol");
		System.out.println(hotel);
		return "adminDeleteHotel";
	}
	//Abhijeet
	@RequestMapping("/adminRooms")
	public String adminRooms(Model model) {
 
		model.addAttribute("obj", new Room());
 
		return "AdminRooms";
	}
	
	//Abhijeet
	@RequestMapping("/hoteldetails")
	public String addRooms(Model model) {
		System.out.println("show hotel list");
		List<Hotel> hotelList;
		try {

			hotelList = hotelService.listHotels();
			model.addAttribute("hotelList", hotelList);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("okay exception");
		}
		return "RoomDetails";

	}
	
//	@RequestMapping("/addAdminRooms")
//	public String addAdminRooms(Model model) {
// 
//		model.addAttribute("obj", new Room());
// 
//		return "AddRooms";
//
//	}
	
	@RequestMapping("/addingroom")
	public String addingroom(@RequestParam("hid") int hid, Model model, HttpServletRequest request) {
		
		Room room =new Room();
		int hotId = hid;
		room.setHotelId(hotId);
		HttpSession session = request.getSession();
		session.setAttribute("hid", hotId);

		model.addAttribute("obj", room);

		return "AddRooms";
	}
	
//	@RequestMapping("/submitDetails")
//	public String submitDetails(@ModelAttribute Booking book, Model model,  HttpServletRequest request) {
//
//		HttpSession session = request.getSession();
//		int roomid = (int) session.getAttribute("id");
//		double amount = (double) session.getAttribute("rate");
//		System.out.println(amount);
//		System.out.println(roomid);
//		System.out.println(book.getAdults());
//		
//		return "";
//	}
	
	@RequestMapping("/newRoomDetails")
	public String addRoomDetails(@ModelAttribute Room room, Model model,  HttpServletRequest request) {
//		double uid = Math.random();
//		int usrId = (int) (uid * 1000);
//		user.setUserId(usrId);
		HttpSession session = request.getSession();
		int hotelId = (int) session.getAttribute("hid");
		roomService.addRoom(room);
		System.out.println(room.getRoomNo());		
		return "RoomConfirmation";
	}
	
	@RequestMapping("/hoteldetail")
	public String hoteldetail(Model model) {
		System.out.println("show hotel list");
		List<Hotel> hotelList;
		try {

			hotelList = hotelService.listHotels();
			model.addAttribute("hotelList", hotelList);
		} catch (Exception ex) {
			ex.printStackTrace();
			System.out.println("okay exception");
		}
		return "HotelDetails2";

	}
	
	@RequestMapping("/deletingroom")
	public String deletingroom(@RequestParam("hid") int hid, Model model, HttpServletRequest request) {
	
			/*System.out.println("In booking hotel room");
			List<Room> roomList;
			System.out.println("In try room");
			int hcode = Integer.parseInt(hid);
			String rtype = rtype;
			roomList = roomService.listRoom(hcode, rtype);
			System.out.println(roomList);
			model.addAttribute("roomList", roomList);
			System.out.println("done2");
			return "HotelBooking";
	*/
			HttpSession session = request.getSession();
			int hotelid = hid;
			 System.out.println("In booking hotel room");
					 List<Room> roomList;
					 try {
					roomList = hotelService.listRoom(hotelid);
					 System.out.println(roomList);
					 model.addAttribute("roomList", roomList);
					 System.out.println("done2");
					 } catch (Exception ex) {
					 ex.printStackTrace();
					 System.out.println("okay exception");}
					 return "RoomDetails2";
		}
	
	@RequestMapping("/deleteRoom")
	public String deleteRoom(@RequestParam("rid") int roomId,Model model) {
			System.out.println("Deleting Rooms...");
			roomService.deleteRoom(roomId);
			System.out.println("Reached deleteRoomSubmit");
			return "DeleteRoom";
	}
	
	@RequestMapping("/modifyroom")
	public String modifyroom(@RequestParam("rid") int roomId, Model model, HttpServletRequest request) {
		System.out.println("Modifying Rooms...");
//		roomService.modifyRoom(roomId);
		System.out.println("Reached deleteRoomSubmit");
		return "ModifyRoom";
		}
}