package com.cg.hms.test;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hms.dao.UserDAOImpl;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.DbUtil;

import junit.framework.Assert;

public class DbConnectionTest {

	static UserDAOImpl userDAO;
	static Connection connection;

	@BeforeClass
	public static void initialise() {
		userDAO = new UserDAOImpl();
		connection = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws HMSException
	 **/
	@Test
	public void test() throws HMSException {
		Connection connection = DbUtil.getConnection();
		Assert.assertNotNull(connection);

	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		userDAO = null;
		connection = null;
	}
}
