package com.cg.hms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.hms.dao.IQueryMapper;
import com.cg.hms.exception.HMSException;

public class DbUtil {
	private static Connection connection = null;

	public static Connection getConnection() throws HMSException {

		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "system", "password");
//		  connection = DriverManager.getConnection(IQueryMapper.URL, IQueryMapper.USERNAME, IQueryMapper.PASSWORD);

		} catch (SQLException e) {
			throw new HMSException("Connection Not Established");

		} 
		return connection;
	}
}
